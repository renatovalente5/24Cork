function En() {
    return {
        "_Contactos": "Contacts",
        "_Produtos": "Products",
        "_Lista_de_Produtos": "List of Products",
        "_Coleção": "Colection",
        "_Início": "Home",
        "_PT": "EN",
        "_Malas": "Suitcase",
        "_Chapeús": "Hats",
        "_Creado_por": "Copyright © 2020 - Created by 24Cork",
        "_Contacte-nos": "Contact Us Now",
        "_Nossos_Produtos": "Our Products",
        "_Novos_Produtos": "New Products",
        "_Envie-nos_uma_mensagem": "Leave a Message!",
        "_mensagem_de_contacto": "Contact us if you are interesting in our products!",
        "_Categoria": "Category",
        "_Ordenar_por": "Sort by:",
        "_Predefinido": "Default",
        "_Price_Low": "Price (Low > High)",
        "_Price_High": "Price (High > Low)",
        "_Produto_Detalhes": "Product Details",
        
    }
}; 


