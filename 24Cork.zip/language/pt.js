function Pt() {
    return {
        "_Contactos": "Contactos",
        "_Produtos": "Produtos",
        "_Lista_de_Produtos": "Lista de Produtos",
        "_Coleção": "Coleção",
        "_Início": "Início",
        "_PT": "PT",
        "_Malas": "Malas",
        "_Chapeús": "Chapeús",
        "_Creado_por": "Copyright © 2020 - Criado por 24Cork",
        "_Contacte-nos": "Contacte-nos",
        "_Nossos_Produtos": "Nossos Produtos",
        "_Novos_Produtos": "Novos Produtos",
        "_Envie-nos_uma_mensagem": "Envie uma mensagem!",
        "_mensagem_de_contacto": "Contacte-nos se estiver interessado nos nossos produtos!",
        "_Categoria": "Categoria",
        "_Ordenar_por": "Ordenar por:",
        "_Predefinido": "Predefinido",
        "_Price_Low": "Preço (Baixo > Alto)",
        "_Price_High": "Preço (Alto > Baixo)",
        "_Produto_Detalhes": "Produto Detalhes",

    }
}; 


// class="lang" key="_List_of_Products"